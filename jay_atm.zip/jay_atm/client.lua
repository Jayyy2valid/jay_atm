local QBCore = exports['qb-core']:GetCoreObject()
local ESX = nil
if GetResourceState('es_extended') == 'started' then
    ESX = exports['es_extended']:getSharedObject()
end

local function GetPlayerBankBalance()
    if QBCore then
        local PlayerData = QBCore.Functions.GetPlayerData()
        return PlayerData.money['bank']
    elseif ESX then
        return ESX.GetPlayerData().accounts[1].money
    else
        return 0
    end
end

local function UpdatePlayerBank(action, amount)
    if QBCore then
        TriggerServerEvent('bank:updateBalance', action, amount)
    elseif ESX then
        TriggerServerEvent('bank:updateBalance', action, amount)
    end
end

local function Notify(type, message)
    if Config.Notifications then
        if QBCore then
            QBCore.Functions.Notify(message, type)
        elseif ESX then
            ESX.ShowNotification(message)
        else
            print(message)
        end
    end
end

local function OpenATMMenu()
    local balance = GetPlayerBankBalance()

    lib.registerContext({
        id = 'atm_menu',
        title = Config.Locale.MenuTitle,
        options = {
            {
                title = Config.Locale.Balance:format(balance),
                icon = 'fas fa-coins',
                disabled = false, 
                onSelect = function()
                    lib.showContext('atm_menu')
                end
            },
            {
                title = Config.Locale.Deposit,
                description = 'Sätt in pengar på ditt bankkonto.',
                icon = 'fas fa-arrow-circle-up',
                onSelect = function()
                    local input = lib.inputDialog(Config.Locale.Deposit, {
                        { type = 'number', label = 'Belopp', placeholder = 'Skriv belopp' }
                    })
                    if input and tonumber(input[1]) > 0 then
                        local confirm = lib.alertDialog({
                            header = 'Bekräfta insättning',
                            content = 'Vill du sätta in ' .. input[1] .. ' SEK?',
                            centered = true,
                            cancel = true
                        })
                        if confirm == 'confirm' then
                            UpdatePlayerBank('deposit', tonumber(input[1]))
                        end
                    end
                end
            },
            {
                title = Config.Locale.Withdraw,
                description = 'Ta ut pengar från ditt bankkonto.',
                icon = 'fas fa-arrow-circle-down',
                onSelect = function()
                    local input = lib.inputDialog(Config.Locale.Withdraw, {
                        { type = 'number', label = 'Belopp', placeholder = 'Skriv belopp' }
                    })
                    if input and tonumber(input[1]) > 0 then
                        local confirm = lib.alertDialog({
                            header = 'Bekräfta uttag',
                            content = 'Vill du ta ut ' .. input[1] .. ' SEK?',
                            centered = true,
                            cancel = true
                        })
                        if confirm == 'confirm' then
                            UpdatePlayerBank('withdraw', tonumber(input[1]))
                        end
                    end
                end
            }
        }
    })
    lib.showContext('atm_menu')
end

for _, model in pairs(Config.ATMProps) do
    exports.ox_target:addModel(model, {
        {
            name = 'atm_menu',
            icon = 'fas fa-credit-card',
            label = Config.Locale.MenuTitle,
            onSelect = function()
                OpenATMMenu()
            end
        }
    })
end