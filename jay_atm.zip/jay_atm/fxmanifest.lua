fx_version 'cerulean'
game 'gta5'

lua54 'yes'

author 'Jay2'
description 'ATM script för esx och qbcore.'
version '1.0.0'

shared_scripts {
    '@ox_lib/init.lua',
    'config.lua'
}

client_script 'client.lua'
server_script 'server.lua'

escrow_ignore {
    'config.lua'
  }
