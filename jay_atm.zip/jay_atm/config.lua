Config = {}

Config.ATMProps = {
    `prop_atm_01`,
    `prop_atm_02`,
    `prop_atm_03`,
    `prop_fleeca_atm`
}

Config.Locale = {
    MenuTitle = 'Bankomat',
    Balance = 'Saldo: %s SEK',
    Deposit = '💷 Sätt in pengar',
    Withdraw = '💶 Ta ut pengar',
    Confirm = 'Bekräfta',
    Cancel = 'Avbryt'
}

Config.Notifications = true -- Notify när du tar ut eller tar in pengar.