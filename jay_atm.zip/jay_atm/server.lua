local QBCore = exports['qb-core']:GetCoreObject()
local ESX = nil
if GetResourceState('es_extended') == 'started' then
    ESX = exports['es_extended']:getSharedObject()
end

RegisterServerEvent('bank:updateBalance', function(action, amount)
    local src = source
    local xPlayer

    if QBCore then
        xPlayer = QBCore.Functions.GetPlayer(src)
    elseif ESX then
        xPlayer = ESX.GetPlayerFromId(src)
    end

    if not xPlayer then return end

    if action == 'deposit' then
        local cash = QBCore and xPlayer.PlayerData.money['cash'] or xPlayer.getMoney()
        if cash >= amount then
            if QBCore then
                xPlayer.Functions.RemoveMoney('cash', amount)
                xPlayer.Functions.AddMoney('bank', amount)
            else
                xPlayer.removeMoney(amount)
                xPlayer.addAccountMoney('bank', amount)
            end
            TriggerClientEvent('ox_lib:notify', src, { type = 'success', description = 'Du har satt in ' .. amount .. ' SEK.' })
        else
            TriggerClientEvent('ox_lib:notify', src, { type = 'error', description = 'Du har inte tillräckligt med kontanter!' })
        end
    elseif action == 'withdraw' then
        local bank = QBCore and xPlayer.PlayerData.money['bank'] or xPlayer.getAccount('bank').money
        if bank >= amount then
            if QBCore then
                xPlayer.Functions.RemoveMoney('bank', amount)
                xPlayer.Functions.AddMoney('cash', amount)
            else
                xPlayer.removeAccountMoney('bank', amount)
                xPlayer.addMoney(amount)
            end
            TriggerClientEvent('ox_lib:notify', src, { type = 'success', description = 'Du har tagit ut ' .. amount .. ' SEK.' })
        else
            TriggerClientEvent('ox_lib:notify', src, { type = 'error', description = 'Du har inte tillräckligt med saldo på banken!' })
        end
    end
end)
